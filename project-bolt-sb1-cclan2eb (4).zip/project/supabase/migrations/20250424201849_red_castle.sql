/*
  # Create courses table and related schemas

  1. New Tables
    - `courses`
      - `id` (uuid, primary key)
      - `title` (text, not null)
      - `description` (text, not null)
      - `image` (text, not null)
      - `instructor` (text, not null)
      - `category` (text, not null)
      - `level` (text, not null)
      - `price` (numeric, not null)
      - `rating` (numeric, default 0)
      - `review_count` (integer, default 0)
      - `students` (integer, default 0)
      - `duration` (text, not null)
      - `updated_at` (timestamptz, default now())
      - `video_hours` (integer, not null)
      - `resources` (integer, not null)
      - `prerequisites` (text)
      - `for_whom` (text)
      - `created_at` (timestamptz, default now())

    - `course_modules`
      - `id` (uuid, primary key)
      - `course_id` (uuid, foreign key)
      - `title` (text, not null)
      - `order` (integer, not null)
      - `created_at` (timestamptz, default now())

    - `course_lessons`
      - `id` (uuid, primary key)
      - `module_id` (uuid, foreign key)
      - `title` (text, not null)
      - `duration` (text, not null)
      - `type` (text, not null)
      - `preview` (boolean, default false)
      - `order` (integer, not null)
      - `created_at` (timestamptz, default now())

    - `course_objectives`
      - `id` (uuid, primary key)
      - `course_id` (uuid, foreign key)
      - `objective` (text, not null)
      - `order` (integer, not null)
      - `created_at` (timestamptz, default now())

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users to read course data
    - Add policies for admin users to manage course data
*/

-- Create courses table
CREATE TABLE IF NOT EXISTS courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  image text NOT NULL,
  instructor text NOT NULL,
  category text NOT NULL,
  level text NOT NULL,
  price numeric NOT NULL,
  rating numeric DEFAULT 0,
  review_count integer DEFAULT 0,
  students integer DEFAULT 0,
  duration text NOT NULL,
  updated_at timestamptz DEFAULT now(),
  video_hours integer NOT NULL,
  resources integer NOT NULL,
  prerequisites text,
  for_whom text,
  created_at timestamptz DEFAULT now()
);

-- Create course_modules table
CREATE TABLE IF NOT EXISTS course_modules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE,
  title text NOT NULL,
  "order" integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create course_lessons table
CREATE TABLE IF NOT EXISTS course_lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id uuid REFERENCES course_modules(id) ON DELETE CASCADE,
  title text NOT NULL,
  duration text NOT NULL,
  type text NOT NULL,
  preview boolean DEFAULT false,
  "order" integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create course_objectives table
CREATE TABLE IF NOT EXISTS course_objectives (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid REFERENCES courses(id) ON DELETE CASCADE,
  objective text NOT NULL,
  "order" integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_modules ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE course_objectives ENABLE ROW LEVEL SECURITY;

-- Create policies for courses
CREATE POLICY "Allow public read access to courses"
  ON courses
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow admin to manage courses"
  ON courses
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

-- Create policies for course_modules
CREATE POLICY "Allow public read access to course_modules"
  ON course_modules
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow admin to manage course_modules"
  ON course_modules
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

-- Create policies for course_lessons
CREATE POLICY "Allow public read access to course_lessons"
  ON course_lessons
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow admin to manage course_lessons"
  ON course_lessons
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');

-- Create policies for course_objectives
CREATE POLICY "Allow public read access to course_objectives"
  ON course_objectives
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Allow admin to manage course_objectives"
  ON course_objectives
  TO authenticated
  USING (auth.jwt() ->> 'role' = 'admin')
  WITH CHECK (auth.jwt() ->> 'role' = 'admin');