import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2.39.7";
import { Configuration, OpenAIApi } from "npm:openai@3.3.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

const openai = new OpenAIApi(new Configuration({
  apiKey: "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"
}));

async function generateCourseRecommendations(query: string) {
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL") ?? "",
    Deno.env.get("SUPABASE_ANON_KEY") ?? ""
  );

  const { data: courses } = await supabase
    .from('courses')
    .select('*')
    .limit(5);

  const prompt = `Based on the query "${query}", analyze these courses and recommend the most relevant ones. Consider the user's interests, skill level, and learning goals. Provide a detailed explanation for each recommendation.

Courses:
${JSON.stringify(courses, null, 2)}

Return response in this format:
{
  "content": "Detailed explanation of recommendations",
  "type": "course",
  "metadata": {
    "courses": [recommended course objects]
  }
}`;

  const completion = await openai.createChatCompletion({
    model: "gpt-3.5-turbo",
    messages: [
      {
        role: "system",
        content: "You are an expert course advisor helping students find the best learning resources."
      },
      {
        role: "user",
        content: prompt
      }
    ],
    temperature: 0.7
  });

  return JSON.parse(completion.data.choices[0].message?.content || "{}");
}

async function generateLearningPath(query: string) {
  const prompt = `Create a detailed learning path based on this request: "${query}"
Include:
1. Clear progression stages
2. Estimated time commitments
3. Key skills to acquire
4. Recommended resources
5. Practical projects
6. Assessment milestones

Return response in this format:
{
  "content": "Detailed learning path in markdown format",
  "type": "text"
}`;

  const completion = await openai.createChatCompletion({
    model: "gpt-3.5-turbo",
    messages: [
      {
        role: "system",
        content: "You are an expert curriculum designer creating personalized learning paths."
      },
      {
        role: "user",
        content: prompt
      }
    ],
    temperature: 0.7
  });

  return JSON.parse(completion.data.choices[0].message?.content || "{}");
}

async function generateCodeExplanation(query: string) {
  const prompt = `Explain this technical concept or code: "${query}"
Include:
1. Clear explanation
2. Code examples
3. Best practices
4. Common pitfalls
5. Practical use cases

Return response in this format:
{
  "content": "Technical explanation with code examples",
  "type": "code"
}`;

  const completion = await openai.createChatCompletion({
    model: "gpt-3.5-turbo",
    messages: [
      {
        role: "system",
        content: "You are an expert programmer explaining technical concepts with practical examples."
      },
      {
        role: "user",
        content: prompt
      }
    ],
    temperature: 0.7
  });

  return JSON.parse(completion.data.choices[0].message?.content || "{}");
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { query } = await req.json();

    let response;
    if (query.toLowerCase().includes('course') || query.toLowerCase().includes('recommend')) {
      response = await generateCourseRecommendations(query);
    } else if (query.toLowerCase().includes('learning path') || query.toLowerCase().includes('roadmap')) {
      response = await generateLearningPath(query);
    } else if (query.toLowerCase().includes('code') || query.toLowerCase().includes('explain') || query.toLowerCase().includes('how to')) {
      response = await generateCodeExplanation(query);
    } else {
      // General response
      const completion = await openai.createChatCompletion({
        model: "gpt-3.5-turbo",
        messages: [
          {
            role: "system",
            content: "You are a helpful AI learning assistant providing guidance on courses, technical concepts, and learning strategies."
          },
          {
            role: "user",
            content: query
          }
        ],
        temperature: 0.7
      });

      response = {
        content: completion.data.choices[0].message?.content,
        type: "text"
      };
    }

    return new Response(
      JSON.stringify(response),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});