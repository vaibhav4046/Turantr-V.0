import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "npm:@supabase/supabase-js@2.39.7";
import { Configuration, OpenAIApi } from "npm:openai@3.3.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

// Replace with your OpenAI API key
const openai = new OpenAIApi(new Configuration({
  apiKey: Deno.env.get("OPENAI_API_KEY") ?? ""
}));

const courseTemplates = [
  {
    title: "Power BI Mastery",
    category: "Business Intelligence",
    level: "Intermediate",
    price: 0, // All courses are free
    image: "https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg",
    moduleCount: 25,
    freeModules: 25 // All modules are free
  },
  {
    title: "Full Stack Development Bootcamp",
    category: "Web Development",
    level: "Advanced",
    price: 0,
    image: "https://images.pexels.com/photos/11035471/pexels-photo-11035471.jpeg",
    moduleCount: 25,
    freeModules: 25
  },
  {
    title: "Tally Prime for Business",
    category: "Accounting",
    level: "Beginner",
    price: 0,
    image: "https://images.pexels.com/photos/6693661/pexels-photo-6693661.jpeg",
    moduleCount: 25,
    freeModules: 25
  }
];

async function generateModuleContent(moduleTitle: string, category: string) {
  const prompt = `Create comprehensive learning content for the module "${moduleTitle}" in ${category}. Include:
  1. Detailed module description
  2. Clear learning objectives
  3. Video script outline
  4. Code examples or practical demonstrations
  5. Interactive exercises
  6. Self-assessment questions
  7. Additional resources and references
  8. Practice assignments
  9. Real-world case studies
  10. Key takeaways

  Format the content in markdown with proper sections, code blocks, and clear structure.`;

  const completion = await openai.createChatCompletion({
    model: "gpt-3.5-turbo",
    messages: [
      {
        role: "system",
        content: "You are an expert course creator generating comprehensive educational content with practical examples and clear explanations."
      },
      {
        role: "user",
        content: prompt
      }
    ],
    temperature: 0.7,
    max_tokens: 2500
  });

  return completion.data.choices[0].message?.content || "";
}

async function generateCourseStructure(template: any) {
  const moduleTopics = await openai.createChatCompletion({
    model: "gpt-3.5-turbo",
    messages: [
      {
        role: "system",
        content: `You are an expert curriculum designer for ${template.category} courses.`
      },
      {
        role: "user",
        content: `Create a comprehensive curriculum with exactly ${template.moduleCount} modules for "${template.title}". Each module should build upon previous knowledge and include both theoretical and practical components. Return as JSON array of module titles.`
      }
    ],
    temperature: 0.7
  });

  const modules = JSON.parse(moduleTopics.data.choices[0].message?.content || "[]");
  
  const courseStructure = {
    description: "",
    instructor: {
      name: "",
      bio: "",
      credentials: ""
    },
    duration: "",
    video_hours: 0,
    resources: 0,
    prerequisites: "",
    for_whom: "",
    modules: [],
    objectives: []
  };

  // Generate course overview
  const courseOverview = await openai.createChatCompletion({
    model: "gpt-3.5-turbo",
    messages: [
      {
        role: "system",
        content: `You are an expert in ${template.category} creating detailed course descriptions.`
      },
      {
        role: "user",
        content: `Create a comprehensive course overview for "${template.title}" including:
        1. Detailed course description
        2. Expert instructor profile
        3. Specific prerequisites
        4. Target audience description
        5. Clear learning objectives
        6. Course duration and resource count
        Return as JSON.`
      }
    ],
    temperature: 0.7
  });

  const overview = JSON.parse(courseOverview.data.choices[0].message?.content || "{}");
  Object.assign(courseStructure, overview);

  // Generate detailed content for each module
  courseStructure.modules = await Promise.all(modules.map(async (moduleTitle: string, index: number) => {
    const content = await generateModuleContent(moduleTitle, template.category);
    
    return {
      title: moduleTitle,
      description: content.split('\n')[0], // First line as description
      order: index + 1,
      lessons: [
        {
          title: `${moduleTitle} - Core Concepts`,
          description: "Comprehensive introduction to key concepts",
          duration: "45 minutes",
          type: "video",
          preview: true,
          content: content,
          order: 1
        },
        {
          title: `${moduleTitle} - Practical Application`,
          description: "Hands-on exercises and implementation",
          duration: "60 minutes",
          type: "interactive",
          preview: true,
          content: content,
          order: 2
        },
        {
          title: `${moduleTitle} - Advanced Topics`,
          description: "Deep dive into advanced concepts",
          duration: "45 minutes",
          type: "video",
          preview: true,
          content: content,
          order: 3
        },
        {
          title: `${moduleTitle} - Project Work`,
          description: "Real-world project implementation",
          duration: "90 minutes",
          type: "project",
          preview: true,
          content: content,
          order: 4
        }
      ]
    };
  }));

  return {
    ...template,
    ...courseStructure,
    rating: 0,
    review_count: 0,
    students: 0
  };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? ""
    );

    // Generate and insert courses
    for (const template of courseTemplates) {
      const courseData = await generateCourseStructure(template);
      const { modules, objectives, ...courseInfo } = courseData;

      // Insert course
      const { data: course, error: courseError } = await supabase
        .from("courses")
        .insert(courseInfo)
        .select()
        .single();

      if (courseError) throw courseError;

      // Insert modules and lessons
      for (const module of modules) {
        const { lessons, ...moduleInfo } = module;
        
        const { data: moduleData, error: moduleError } = await supabase
          .from("course_modules")
          .insert({ ...moduleInfo, course_id: course.id })
          .select()
          .single();

        if (moduleError) throw moduleError;

        // Insert lessons for this module
        const lessonsToInsert = lessons.map(lesson => ({
          ...lesson,
          module_id: moduleData.id
        }));

        const { error: lessonsError } = await supabase
          .from("course_lessons")
          .insert(lessonsToInsert);

        if (lessonsError) throw lessonsError;
      }

      // Insert course objectives
      const objectivesToInsert = objectives.map((objective, index) => ({
        course_id: course.id,
        objective,
        order: index + 1
      }));

      const { error: objectivesError } = await supabase
        .from("course_objectives")
        .insert(objectivesToInsert);

      if (objectivesError) throw objectivesError;
    }

    return new Response(
      JSON.stringify({ 
        message: "Courses generated successfully", 
        count: courseTemplates.length 
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});