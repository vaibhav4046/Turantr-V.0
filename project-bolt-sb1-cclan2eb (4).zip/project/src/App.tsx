import React, { useState } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import Layout from './components/layout/Layout';
import HomePage from './pages/HomePage';
import CoursesPage from './pages/CoursesPage';
import CourseDetailPage from './pages/CourseDetailPage';
import DashboardPage from './pages/DashboardPage';
import AiAssistantPage from './pages/AiAssistantPage';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

function App() {
  const [selectedCourse, setSelectedCourse] = useState(null);

  return (
    <BrowserRouter>
      <ThemeProvider>
        <Layout>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/courses" element={<CoursesPage setSelectedCourse={setSelectedCourse} />} />
            <Route path="/courses/:courseId" element={<CourseDetailPage selectedCourse={selectedCourse} />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/ai-assistant" element={<AiAssistantPage />} />
          </Routes>
        </Layout>
      </ThemeProvider>
    </BrowserRouter>
  );
}

export default App;