// Sample course data for the learning platform

export const allCourses = [
  {
    id: 1,
    title: "Full Stack Web Development Bootcamp",
    description: "A comprehensive journey from HTML basics to building complex web applications with modern frameworks and tools.",
    image: "https://images.pexels.com/photos/11035471/pexels-photo-11035471.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    instructor: "Sarah Johnson",
    category: "Web Development",
    level: "Beginner",
    price: "49.99",
    rating: 4.8,
    reviewCount: 1245,
    students: 15432,
    duration: "48 hours",
    updatedAt: "June 2025",
    videoHours: 48,
    resources: 24,
    whatYouWillLearn: [
      "Build responsive websites with HTML, CSS, and JavaScript",
      "Create dynamic web applications with React",
      "Develop backend APIs with Node.js and Express",
      "Work with databases like MongoDB and PostgreSQL",
      "Deploy applications to production environments"
    ],
    prerequisites: "Basic computer knowledge. No prior programming experience required.",
    forWhom: "aspiring web developers and those looking to transition into tech careers",
    modules: [
      {
        title: "Web Fundamentals",
        lessons: [
          { title: "Introduction to HTML", duration: "45 min", type: "video", preview: true },
          { title: "CSS Basics", duration: "55 min", type: "video", preview: false },
          { title: "JavaScript Essentials", duration: "65 min", type: "video", preview: false },
          { title: "Building Your First Webpage", duration: "30 min", type: "text", preview: false },
        ]
      },
      {
        title: "Frontend Development",
        lessons: [
          { title: "Introduction to React", duration: "60 min", type: "video", preview: false },
          { title: "React Components", duration: "70 min", type: "video", preview: false },
          { title: "State Management with Redux", duration: "80 min", type: "video", preview: false },
          { title: "Building a Frontend Project", duration: "120 min", type: "video", preview: false },
        ]
      },
      {
        title: "Backend Development",
        lessons: [
          { title: "Node.js Fundamentals", duration: "55 min", type: "video", preview: false },
          { title: "RESTful API Development", duration: "65 min", type: "video", preview: false },
          { title: "Database Integration", duration: "75 min", type: "video", preview: false },
          { title: "Authentication & Authorization", duration: "60 min", type: "video", preview: false },
        ]
      }
    ]
  },
  {
    id: 2,
    title: "Data Science Essentials",
    description: "Master the core concepts and tools needed for data analysis, visualization, and building predictive models.",
    image: "https://images.pexels.com/photos/669615/pexels-photo-669615.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    instructor: "Dr. Michael Chen",
    category: "Data Science",
    level: "Intermediate",
    price: "59.99",
    rating: 4.7,
    reviewCount: 987,
    students: 8765,
    duration: "36 hours",
    updatedAt: "May 2025",
    videoHours: 36,
    resources: 18,
    whatYouWillLearn: [
      "Analyze and visualize data using Python and popular libraries",
      "Apply statistical methods to extract insights from datasets",
      "Build machine learning models for prediction and classification",
      "Create compelling data stories and visualizations",
      "Work with real-world datasets and solve practical problems"
    ],
    prerequisites: "Basic Python knowledge and understanding of algebra and statistics",
    forWhom: "aspiring data scientists, analysts, and professionals looking to leverage data in their roles",
    modules: [
      {
        title: "Data Analysis Fundamentals",
        lessons: [
          { title: "Introduction to Data Science", duration: "40 min", type: "video", preview: true },
          { title: "Python for Data Analysis", duration: "60 min", type: "video", preview: false },
          { title: "Working with Pandas", duration: "75 min", type: "video", preview: false },
          { title: "Data Cleaning and Preprocessing", duration: "65 min", type: "video", preview: false },
        ]
      },
      {
        title: "Data Visualization",
        lessons: [
          { title: "Visualization Principles", duration: "50 min", type: "video", preview: false },
          { title: "Creating Charts with Matplotlib", duration: "65 min", type: "video", preview: false },
          { title: "Interactive Visualizations with Plotly", duration: "70 min", type: "video", preview: false },
          { title: "Building a Dashboard", duration: "90 min", type: "video", preview: false },
        ]
      },
      {
        title: "Machine Learning Basics",
        lessons: [
          { title: "Introduction to Machine Learning", duration: "55 min", type: "video", preview: false },
          { title: "Regression Models", duration: "75 min", type: "video", preview: false },
          { title: "Classification Algorithms", duration: "80 min", type: "video", preview: false },
          { title: "Model Evaluation", duration: "60 min", type: "video", preview: false },
        ]
      }
    ]
  },
  {
    id: 3,
    title: "No-Code App Development Masterclass",
    description: "Learn to build powerful web and mobile applications without writing a single line of code.",
    image: "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    instructor: "Jessica Williams",
    category: "No-Code",
    level: "Beginner",
    price: "39.99",
    rating: 4.9,
    reviewCount: 756,
    students: 6543,
    duration: "24 hours",
    updatedAt: "July 2025",
    videoHours: 24,
    resources: 15,
    whatYouWillLearn: [
      "Build fully-functional web applications using Bubble.io",
      "Create mobile apps with Adalo without coding",
      "Design beautiful interfaces with modern no-code design tools",
      "Implement complex workflows and business logic",
      "Connect your apps to databases and external APIs"
    ],
    prerequisites: "No technical prerequisites. Just a willingness to learn!",
    forWhom: "entrepreneurs, business professionals, and anyone looking to bring their app ideas to life without coding",
    modules: [
      {
        title: "No-Code Fundamentals",
        lessons: [
          { title: "Introduction to No-Code Development", duration: "30 min", type: "video", preview: true },
          { title: "Comparing No-Code Platforms", duration: "45 min", type: "video", preview: false },
          { title: "Planning Your Application", duration: "40 min", type: "video", preview: false },
          { title: "Design Principles for No-Code Apps", duration: "50 min", type: "video", preview: false },
        ]
      },
      {
        title: "Building with Bubble.io",
        lessons: [
          { title: "Bubble.io Interface Overview", duration: "35 min", type: "video", preview: false },
          { title: "Creating Data Types and Database", duration: "55 min", type: "video", preview: false },
          { title: "Building UI Elements", duration: "60 min", type: "video", preview: false },
          { title: "Implementing Workflows", duration: "70 min", type: "video", preview: false },
        ]
      },
      {
        title: "Mobile App Development",
        lessons: [
          { title: "Introduction to Adalo", duration: "40 min", type: "video", preview: false },
          { title: "Designing Mobile Interfaces", duration: "50 min", type: "video", preview: false },
          { title: "Creating Mobile Navigation", duration: "45 min", type: "video", preview: false },
          { title: "Publishing Your Mobile App", duration: "35 min", type: "video", preview: false },
        ]
      }
    ]
  },
  {
    id: 4,
    title: "Power BI for Business Intelligence",
    description: "Transform your business data into powerful insights and visualizations that drive decision-making.",
    image: "https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    instructor: "Robert Thompson",
    category: "Business",
    level: "Intermediate",
    price: "49.99",
    rating: 4.6,
    reviewCount: 543,
    students: 4321,
    duration: "30 hours",
    updatedAt: "April 2025",
    videoHours: 30,
    resources: 22,
    whatYouWillLearn: [
      "Import and transform data from various sources",
      "Create interactive dashboards and reports",
      "Use DAX formulas for advanced calculations",
      "Design visually appealing and informative visualizations",
      "Share and publish reports for stakeholders"
    ],
    prerequisites: "Basic Excel knowledge and familiarity with business data concepts",
    forWhom: "business analysts, managers, and professionals who work with data and need to create reports",
    modules: [
      {
        title: "Power BI Fundamentals",
        lessons: [
          { title: "Introduction to Power BI", duration: "45 min", type: "video", preview: true },
          { title: "Connecting to Data Sources", duration: "55 min", type: "video", preview: false },
          { title: "Data Cleaning with Power Query", duration: "65 min", type: "video", preview: false },
          { title: "Creating Your First Report", duration: "70 min", type: "video", preview: false },
        ]
      },
      {
        title: "Data Modeling and Visualization",
        lessons: [
          { title: "Data Modeling Concepts", duration: "50 min", type: "video", preview: false },
          { title: "Creating Relationships", duration: "60 min", type: "video", preview: false },
          { title: "Visualization Best Practices", duration: "55 min", type: "video", preview: false },
          { title: "Advanced Chart Types", duration: "65 min", type: "video", preview: false },
        ]
      },
      {
        title: "Advanced Power BI",
        lessons: [
          { title: "Introduction to DAX", duration: "75 min", type: "video", preview: false },
          { title: "Creating Calculated Columns and Measures", duration: "85 min", type: "video", preview: false },
          { title: "Time Intelligence Functions", duration: "70 min", type: "video", preview: false },
          { title: "Publishing and Sharing Reports", duration: "50 min", type: "video", preview: false },
        ]
      }
    ]
  },
  {
    id: 5,
    title: "Zoho CRM: Complete Guide",
    description: "Master Zoho CRM to streamline your sales processes, manage customer relationships, and boost business growth.",
    image: "https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    instructor: "Amanda Rodriguez",
    category: "Business",
    level: "Beginner",
    price: "44.99",
    rating: 4.5,
    reviewCount: 432,
    students: 3210,
    duration: "25 hours",
    updatedAt: "March 2025",
    videoHours: 25,
    resources: 18,
    whatYouWillLearn: [
      "Set up and customize Zoho CRM for your business needs",
      "Manage leads, contacts, and deals effectively",
      "Automate sales workflows and processes",
      "Generate insightful reports and analytics",
      "Integrate Zoho CRM with other business tools"
    ],
    prerequisites: "No technical prerequisites. Basic understanding of sales processes is helpful.",
    forWhom: "sales professionals, business owners, and teams looking to implement or optimize their CRM system",
    modules: [
      {
        title: "Zoho CRM Fundamentals",
        lessons: [
          { title: "Introduction to Zoho CRM", duration: "40 min", type: "video", preview: true },
          { title: "Setting Up Your Account", duration: "50 min", type: "video", preview: false },
          { title: "Navigating the Interface", duration: "45 min", type: "video", preview: false },
          { title: "Adding Users and Permissions", duration: "55 min", type: "video", preview: false },
        ]
      },
      {
        title: "Managing Customer Data",
        lessons: [
          { title: "Lead Management", duration: "60 min", type: "video", preview: false },
          { title: "Contact and Account Management", duration: "65 min", type: "video", preview: false },
          { title: "Deal Pipeline Configuration", duration: "70 min", type: "video", preview: false },
          { title: "Customizing Fields and Layouts", duration: "55 min", type: "video", preview: false },
        ]
      },
      {
        title: "Automation and Integration",
        lessons: [
          { title: "Workflow Automation", duration: "75 min", type: "video", preview: false },
          { title: "Email Integration", duration: "60 min", type: "video", preview: false },
          { title: "Creating Reports and Dashboards", duration: "70 min", type: "video", preview: false },
          { title: "Integrating with Other Zoho Products", duration: "65 min", type: "video", preview: false },
        ]
      }
    ]
  },
  {
    id: 6,
    title: "Tally Prime for Business Accounting",
    description: "Learn to use Tally Prime for efficient financial management, accounting, and GST compliance.",
    image: "https://images.pexels.com/photos/6693661/pexels-photo-6693661.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    instructor: "Arun Patel",
    category: "Business",
    level: "Beginner",
    price: "34.99",
    rating: 4.7,
    reviewCount: 387,
    students: 2987,
    duration: "22 hours",
    updatedAt: "February 2025",
    videoHours: 22,
    resources: 15,
    whatYouWillLearn: [
      "Set up company information and chart of accounts in Tally",
      "Record daily financial transactions accurately",
      "Generate and analyze financial reports",
      "Manage inventory and create purchase orders",
      "Handle GST compliance and tax filing"
    ],
    prerequisites: "Basic understanding of accounting principles",
    forWhom: "accountants, business owners, and finance professionals looking to master Tally for business accounting",
    modules: [
      {
        title: "Tally Fundamentals",
        lessons: [
          { title: "Introduction to Tally Prime", duration: "35 min", type: "video", preview: true },
          { title: "Creating Company and Masters", duration: "55 min", type: "video", preview: false },
          { title: "Chart of Accounts Setup", duration: "60 min", type: "video", preview: false },
          { title: "Basic Navigation and Shortcuts", duration: "40 min", type: "video", preview: false },
        ]
      },
      {
        title: "Daily Transactions",
        lessons: [
          { title: "Recording Sales and Purchases", duration: "65 min", type: "video", preview: false },
          { title: "Bank and Cash Transactions", duration: "55 min", type: "video", preview: false },
          { title: "Credit Notes and Debit Notes", duration: "50 min", type: "video", preview: false },
          { title: "Journal Entries", duration: "60 min", type: "video", preview: false },
        ]
      },
      {
        title: "GST and Reporting",
        lessons: [
          { title: "GST Setup and Configuration", duration: "70 min", type: "video", preview: false },
          { title: "GST Return Filing", duration: "75 min", type: "video", preview: false },
          { title: "Financial Reports", duration: "65 min", type: "video", preview: false },
          { title: "Data Backup and Security", duration: "45 min", type: "video", preview: false },
        ]
      }
    ]
  },
  {
    id: 7,
    title: "Digital Marketing Fundamentals",
    description: "Master the essential strategies and tools needed to create effective digital marketing campaigns.",
    image: "https://images.pexels.com/photos/905163/pexels-photo-905163.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    instructor: "Emily Clark",
    category: "Marketing",
    level: "Beginner",
    price: "39.99",
    rating: 4.8,
    reviewCount: 654,
    students: 7654,
    duration: "28 hours",
    updatedAt: "May 2025",
    videoHours: 28,
    resources: 20,
    whatYouWillLearn: [
      "Develop comprehensive digital marketing strategies",
      "Create and optimize content for search engines",
      "Run effective social media marketing campaigns",
      "Implement email marketing best practices",
      "Analyze campaign performance and ROI"
    ],
    prerequisites: "No prior marketing experience needed",
    forWhom: "aspiring marketers, business owners, and anyone looking to promote products or services online",
    modules: [
      {
        title: "Digital Marketing Strategy",
        lessons: [
          { title: "Introduction to Digital Marketing", duration: "45 min", type: "video", preview: true },
          { title: "Creating Customer Personas", duration: "55 min", type: "video", preview: false },
          { title: "Setting Marketing Goals", duration: "50 min", type: "video", preview: false },
          { title: "Digital Marketing Channels Overview", duration: "60 min", type: "video", preview: false },
        ]
      },
      {
        title: "Content and SEO Marketing",
        lessons: [
          { title: "Content Marketing Fundamentals", duration: "65 min", type: "video", preview: false },
          { title: "SEO Best Practices", duration: "75 min", type: "video", preview: false },
          { title: "Keyword Research", duration: "60 min", type: "video", preview: false },
          { title: "Creating SEO-Friendly Content", duration: "70 min", type: "video", preview: false },
        ]
      },
      {
        title: "Social Media Marketing",
        lessons: [
          { title: "Social Media Strategy", duration: "55 min", type: "video", preview: false },
          { title: "Facebook and Instagram Marketing", duration: "65 min", type: "video", preview: false },
          { title: "LinkedIn and Twitter Marketing", duration: "60 min", type: "video", preview: false },
          { title: "Social Media Analytics", duration: "50 min", type: "video", preview: false },
        ]
      }
    ]
  },
  {
    id: 8,
    title: "UI/UX Design Essentials",
    description: "Learn to create beautiful, user-friendly interfaces that engage and delight users.",
    image: "https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    instructor: "David Miller",
    category: "Design",
    level: "Intermediate",
    price: "54.99",
    rating: 4.9,
    reviewCount: 876,
    students: 6543,
    duration: "32 hours",
    updatedAt: "June 2025",
    videoHours: 32,
    resources: 25,
    whatYouWillLearn: [
      "Apply user-centered design principles",
      "Create wireframes and prototypes",
      "Design visually appealing interfaces",
      "Conduct user research and usability testing",
      "Build a professional UI/UX portfolio"
    ],
    prerequisites: "Basic design knowledge is helpful but not required",
    forWhom: "aspiring UI/UX designers, web designers, and product managers",
    modules: [
      {
        title: "UI/UX Fundamentals",
        lessons: [
          { title: "Introduction to UI/UX Design", duration: "50 min", type: "video", preview: true },
          { title: "User-Centered Design Principles", duration: "60 min", type: "video", preview: false },
          { title: "Design Thinking Process", duration: "55 min", type: "video", preview: false },
          { title: "Information Architecture", duration: "65 min", type: "video", preview: false },
        ]
      },
      {
        title: "Wireframing and Prototyping",
        lessons: [
          { title: "Sketching and Ideation", duration: "45 min", type: "video", preview: false },
          { title: "Creating Wireframes", duration: "70 min", type: "video", preview: false },
          { title: "Interactive Prototyping", duration: "75 min", type: "video", preview: false },
          { title: "User Testing with Prototypes", duration: "65 min", type: "video", preview: false },
        ]
      },
      {
        title: "Visual Design",
        lessons: [
          { title: "Color Theory for UI Design", duration: "55 min", type: "video", preview: false },
          { title: "Typography in UI Design", duration: "60 min", type: "video", preview: false },
          { title: "Design Systems", duration: "80 min", type: "video", preview: false },
          { title: "Responsive Design Principles", duration: "70 min", type: "video", preview: false },
        ]
      }
    ]
  },
  {
    id: 9,
    title: "Advanced JavaScript Programming",
    description: "Take your JavaScript skills to the next level with advanced concepts, patterns, and modern features.",
    image: "https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    instructor: "James Wilson",
    category: "Web Development",
    level: "Advanced",
    price: "59.99",
    rating: 4.8,
    reviewCount: 765,
    students: 5432,
    duration: "34 hours",
    updatedAt: "April 2025",
    videoHours: 34,
    resources: 22,
    whatYouWillLearn: [
      "Master advanced JavaScript concepts and patterns",
      "Write clean, efficient, and maintainable code",
      "Implement object-oriented programming in JavaScript",
      "Work with asynchronous programming and Promises",
      "Utilize modern ES6+ features effectively"
    ],
    prerequisites: "Solid foundation in JavaScript basics and DOM manipulation",
    forWhom: "intermediate JavaScript developers looking to advance their skills",
    modules: [
      {
        title: "Advanced JavaScript Concepts",
        lessons: [
          { title: "Scope and Closures", duration: "55 min", type: "video", preview: true },
          { title: "This Keyword and Execution Context", duration: "65 min", type: "video", preview: false },
          { title: "Prototypal Inheritance", duration: "70 min", type: "video", preview: false },
          { title: "Functional Programming in JavaScript", duration: "75 min", type: "video", preview: false },
        ]
      },
      {
        title: "Modern JavaScript Features",
        lessons: [
          { title: "ES6+ Syntax and Features", duration: "60 min", type: "video", preview: false },
          { title: "Destructuring and Spread Operator", duration: "50 min", type: "video", preview: false },
          { title: "Modules and Module Patterns", duration: "65 min", type: "video", preview: false },
          { title: "Symbols, Iterators, and Generators", duration: "70 min", type: "video", preview: false },
        ]
      },
      {
        title: "Asynchronous JavaScript",
        lessons: [
          { title: "Callbacks and Callback Hell", duration: "55 min", type: "video", preview: false },
          { title: "Promises and Promise Chaining", duration: "75 min", type: "video", preview: false },
          { title: "Async/Await", duration: "70 min", type: "video", preview: false },
          { title: "Error Handling in Async Code", duration: "60 min", type: "video", preview: false },
        ]
      }
    ]
  },
  {
    id: 10,
    title: "AI for Business: Practical Applications",
    description: "Learn how to implement AI solutions to solve real business problems and gain competitive advantage.",
    image: "https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    instructor: "Dr. Lisa Zhang",
    category: "Business",
    level: "Intermediate",
    price: "64.99",
    rating: 4.7,
    reviewCount: 543,
    students: 3210,
    duration: "30 hours",
    updatedAt: "July 2025",
    videoHours: 30,
    resources: 18,
    whatYouWillLearn: [
      "Identify business problems that can be solved with AI",
      "Implement practical AI solutions using no-code tools",
      "Understand the limitations and ethical considerations of AI",
      "Measure and optimize AI implementation ROI",
      "Develop an AI strategy for your organization"
    ],
    prerequisites: "Basic business understanding. No technical or programming knowledge required.",
    forWhom: "business leaders, managers, and professionals looking to leverage AI in their organizations",
    modules: [
      {
        title: "AI Business Fundamentals",
        lessons: [
          { title: "Introduction to AI for Business", duration: "45 min", type: "video", preview: true },
          { title: "AI Use Cases Across Industries", duration: "60 min", type: "video", preview: false },
          { title: "AI Readiness Assessment", duration: "50 min", type: "video", preview: false },
          { title: "Building an AI Strategy", duration: "55 min", type: "video", preview: false },
        ]
      },
      {
        title: "Practical AI Implementation",
        lessons: [
          { title: "No-Code AI Platforms", duration: "65 min", type: "video", preview: false },
          { title: "Customer Service Automation", duration: "70 min", type: "video", preview: false },
          { title: "Predictive Analytics for Business", duration: "75 min", type: "video", preview: false },
          { title: "AI for Marketing Optimization", duration: "60 min", type: "video", preview: false },
        ]
      },
      {
        title: "AI Management and Ethics",
        lessons: [
          { title: "Measuring AI ROI", duration: "55 min", type: "video", preview: false },
          { title: "Managing AI Projects", duration: "65 min", type: "video", preview: false },
          { title: "AI Ethics and Responsible Use", duration: "70 min", type: "video", preview: false },
          { title: "Future of AI in Business", duration: "50 min", type: "video", preview: false },
        ]
      }
    ]
  }
];

export const featuredCourses = allCourses.slice(0, 6);