import React from 'react';
import { Star, Clock, Users } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';

interface CourseCardProps {
  course: any;
}

const CourseCard: React.FC<CourseCardProps> = ({ course }) => {
  const { theme } = useTheme();

  const getLevelColor = (level: string) => {
    if (theme === 'dark') {
      switch (level) {
        case 'Beginner': return 'bg-green-900/20 text-green-300';
        case 'Intermediate': return 'bg-yellow-900/20 text-yellow-300';
        case 'Advanced': return 'bg-red-900/20 text-red-300';
        default: return 'bg-blue-900/20 text-blue-300';
      }
    } else {
      switch (level) {
        case 'Beginner': return 'bg-green-100 text-green-800';
        case 'Intermediate': return 'bg-yellow-100 text-yellow-800';
        case 'Advanced': return 'bg-red-100 text-red-800';
        default: return 'bg-blue-100 text-blue-800';
      }
    }
  };

  return (
    <div 
      className={`rounded-xl overflow-hidden shadow-sm transition-all duration-300 h-full flex flex-col ${
        theme === 'dark' 
          ? 'bg-gray-800 hover:bg-gray-700 hover:shadow-xl' 
          : 'bg-white hover:shadow-xl'
      }`}
    >
      {/* Course Image */}
      <div className="relative h-48 overflow-hidden">
        <img 
          src={course.image} 
          alt={course.title} 
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
        />
        <div className="absolute top-3 left-3 flex flex-wrap gap-2">
          <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getLevelColor(course.level)}`}>
            {course.level}
          </span>
        </div>
        {course.price === 'Free' && (
          <div className="absolute top-3 right-3">
            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-500 text-white">
              Free
            </span>
          </div>
        )}
      </div>
      
      {/* Course Content */}
      <div className="p-4 flex-grow flex flex-col">
        <div className="flex items-center gap-1 mb-2">
          <span className="text-yellow-400 flex items-center">
            <Star className="fill-current w-4 h-4" />
          </span>
          <span className="text-sm font-medium">{course.rating}</span>
          <span className="text-xs opacity-70">({course.reviewCount} reviews)</span>
        </div>
        
        <h3 className="font-semibold mb-2 line-clamp-2">{course.title}</h3>
        <p className="text-sm opacity-75 mb-3 line-clamp-2">{course.description}</p>
        
        <div className="mt-auto">
          <div className="flex items-center justify-between text-sm mb-3">
            <div className="flex items-center">
              <Clock className="w-4 h-4 mr-1 opacity-70" />
              <span>{course.duration}</span>
            </div>
            <div className="flex items-center">
              <Users className="w-4 h-4 mr-1 opacity-70" />
              <span>{course.students} students</span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm">{course.instructor}</span>
            <span className="font-medium">
              {course.price === 'Free' ? (
                <span className={theme === 'dark' ? 'text-blue-300' : 'text-blue-600'}>Free</span>
              ) : (
                `$${course.price}`
              )}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseCard;