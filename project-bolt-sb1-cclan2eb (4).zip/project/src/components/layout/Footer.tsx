import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, ExternalLink } from 'lucide-react';
import { useTheme } from '../../context/ThemeContext';
import Logo from '../ui/Logo';

const Footer: React.FC = () => {
  const { theme } = useTheme();
  const currentYear = new Date().getFullYear();

  return (
    <footer className={`${theme === 'dark' ? 'bg-gray-950 text-gray-300' : 'bg-gray-100 text-gray-700'} py-12`}>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <Logo className="h-8 w-8" />
              <span className="font-bold text-xl">Turantr</span>
            </div>
            <p className="text-sm">
              AI-powered learning platform with personalized courses and intelligent learning assistance.
            </p>
            <div className="mt-4 flex items-center">
              <span className="text-sm">Made with</span>
              <Heart className="h-4 w-4 mx-1 text-red-500 fill-current" />
              <span className="text-sm">by Turantr Team</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {['Home', 'Courses', 'Dashboard', 'AI Assistant'].map((item) => (
                <li key={item}>
                  <Link
                    to={`/${item === 'Home' ? '' : item.toLowerCase().replace(' ', '-')}`}
                    className={`text-sm hover:underline ${
                      theme === 'dark' ? 'hover:text-blue-300' : 'hover:text-blue-600'
                    }`}
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resource Links */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              {['Blog', 'Tutorials', 'Help Center', 'Contact Us'].map((item) => (
                <li key={item}>
                  <Link
                    to="#"
                    className={`text-sm hover:underline ${
                      theme === 'dark' ? 'hover:text-blue-300' : 'hover:text-blue-600'
                    }`}
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Popular Topics */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Popular Topics</h3>
            <div className="flex flex-wrap gap-2">
              {['Web Development', 'AI', 'Data Science', 'No Code', 'Zoho', 'Tally', 'Power BI'].map((tag) => (
                <span
                  key={tag}
                  className={`inline-flex items-center px-3 py-1 text-xs rounded-full ${
                    theme === 'dark'
                      ? 'bg-gray-800 text-gray-200 hover:bg-gray-700'
                      : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
                  } transition-colors cursor-pointer`}
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-700 flex flex-col md:flex-row justify-between items-center">
          <p className="text-sm">
            &copy; {currentYear} Turantr Learning. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <Link to="#" className="text-sm hover:underline flex items-center">
              Privacy Policy
            </Link>
            <Link to="#" className="text-sm hover:underline flex items-center">
              Terms of Service
            </Link>
            <Link to="#" className="text-sm hover:underline flex items-center">
              Cookie Policy <ExternalLink className="ml-1 h-3 w-3" />
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;