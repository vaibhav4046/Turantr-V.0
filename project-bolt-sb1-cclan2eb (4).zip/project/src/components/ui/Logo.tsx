import React from 'react';
import { Lightbulb } from 'lucide-react';

interface LogoProps {
  className?: string;
}

const Logo: React.FC<LogoProps> = ({ className = "h-6 w-6" }) => {
  return (
    <div className={`relative flex-shrink-0 ${className}`}>
      <Lightbulb className="text-blue-500 fill-blue-500/20 stroke-[2.5]" />
      <div className="absolute inset-0 bg-gradient-to-tr from-purple-500 to-blue-500 opacity-30 rounded-full blur-sm"></div>
    </div>
  );
};

export default Logo;