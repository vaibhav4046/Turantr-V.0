import React from 'react';

interface SkillsRadarChartProps {
  theme: string;
}

const SkillsRadarChart: React.FC<SkillsRadarChartProps> = ({ theme }) => {
  // Mock data for the skills radar chart
  const skills = [
    { name: 'Web Dev', value: 80 },
    { name: 'Data', value: 60 },
    { name: 'Design', value: 40 },
    { name: 'Business', value: 70 },
    { name: 'Marketing', value: 30 },
  ];
  
  // SVG parameters
  const centerX = 150;
  const centerY = 120;
  const radius = 100;
  
  // Calculate polygon points for each skill level
  const calculatePoints = (skillset: typeof skills) => {
    return skillset.map((skill, idx) => {
      const angle = (Math.PI * 2 * idx) / skillset.length - Math.PI / 2;
      const scaledRadius = (radius * skill.value) / 100;
      const x = centerX + scaledRadius * Math.cos(angle);
      const y = centerY + scaledRadius * Math.sin(angle);
      return `${x},${y}`;
    }).join(' ');
  };
  
  return (
    <div className="h-full flex justify-center items-center">
      <svg width="300" height="240" viewBox="0 0 300 240">
        {/* Background circles */}
        {[20, 40, 60, 80, 100].map((level) => (
          <circle
            key={level}
            cx={centerX}
            cy={centerY}
            r={(radius * level) / 100}
            fill="none"
            stroke={theme === 'dark' ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)'}
            strokeWidth="1"
          />
        ))}
        
        {/* Spokes */}
        {skills.map((skill, idx) => {
          const angle = (Math.PI * 2 * idx) / skills.length - Math.PI / 2;
          const x = centerX + radius * Math.cos(angle);
          const y = centerY + radius * Math.sin(angle);
          
          return (
            <line
              key={idx}
              x1={centerX}
              y1={centerY}
              x2={x}
              y2={y}
              stroke={theme === 'dark' ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)'}
              strokeWidth="1"
            />
          );
        })}
        
        {/* Data polygon */}
        <polygon
          points={calculatePoints(skills)}
          fill={theme === 'dark' ? 'rgba(59, 130, 246, 0.3)' : 'rgba(59, 130, 246, 0.2)'}
          stroke={theme === 'dark' ? '#3B82F6' : '#2563EB'}
          strokeWidth="2"
        />
        
        {/* Data points */}
        {skills.map((skill, idx) => {
          const angle = (Math.PI * 2 * idx) / skills.length - Math.PI / 2;
          const scaledRadius = (radius * skill.value) / 100;
          const x = centerX + scaledRadius * Math.cos(angle);
          const y = centerY + scaledRadius * Math.sin(angle);
          
          return (
            <circle
              key={idx}
              cx={x}
              cy={y}
              r="4"
              fill={theme === 'dark' ? '#3B82F6' : '#2563EB'}
            />
          );
        })}
        
        {/* Labels */}
        {skills.map((skill, idx) => {
          const angle = (Math.PI * 2 * idx) / skills.length - Math.PI / 2;
          const labelRadius = radius + 20;
          const x = centerX + labelRadius * Math.cos(angle);
          const y = centerY + labelRadius * Math.sin(angle);
          
          // Adjust text anchors based on position
          let textAnchor = 'middle';
          if (Math.abs(angle) < Math.PI / 4 || Math.abs(angle - Math.PI) < Math.PI / 4) {
            textAnchor = 'start';
          } else if (Math.abs(angle - Math.PI / 2) < Math.PI / 4 || Math.abs(angle + Math.PI / 2) < Math.PI / 4) {
            textAnchor = 'middle';
          } else {
            textAnchor = 'end';
          }
          
          return (
            <text
              key={idx}
              x={x}
              y={y}
              textAnchor={textAnchor}
              dominantBaseline="middle"
              fontSize="12"
              fill={theme === 'dark' ? 'rgba(255,255,255,0.7)' : 'rgba(0,0,0,0.7)'}
            >
              {skill.name} ({skill.value}%)
            </text>
          );
        })}
      </svg>
    </div>
  );
};

export default SkillsRadarChart;