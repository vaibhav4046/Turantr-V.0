import React from 'react';

interface ProgressChartProps {
  theme: string;
}

const ProgressChart: React.FC<ProgressChartProps> = ({ theme }) => {
  // Mock data for the learning progress chart
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
  const hoursSpent = [5, 12, 8, 14, 10, 18];
  const maxHours = Math.max(...hoursSpent);
  
  return (
    <div className="h-64">
      <div className="flex h-full flex-col">
        <div className="flex-grow flex space-x-2">
          {hoursSpent.map((hours, idx) => {
            const heightPercentage = (hours / maxHours) * 100;
            
            return (
              <div key={idx} className="flex-1 flex flex-col justify-end">
                <div 
                  className={`rounded-t-md ${
                    theme === 'dark' ? 'bg-blue-500/70' : 'bg-blue-500'
                  }`}
                  style={{ height: `${heightPercentage}%` }}
                >
                  <div className="px-2 py-1 text-center text-xs text-white font-medium">
                    {hours}h
                  </div>
                </div>
                <div className="text-center mt-2 text-xs opacity-70">
                  {months[idx]}
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="mt-4 text-center text-sm opacity-75">
          Hours spent learning over the last 6 months
        </div>
      </div>
    </div>
  );
};

export default ProgressChart;