import React, { useState, useRef, useEffect } from 'react';
import { Send, Sparkles, User, Bot, ArrowUp, ArrowDown, ChevronRight, CornerDownRight, Brain, BookOpen, Code, FileText } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { allCourses } from '../data/courses';
import { supabase } from '../lib/supabase';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  type?: 'text' | 'code' | 'course' | 'resource';
  metadata?: any;
}

const AiAssistantPage: React.FC = () => {
  const { theme } = useTheme();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: "Hi! I'm your AI learning assistant. I can help you with:\n\n• Finding the right courses for your goals\n• Creating personalized learning paths\n• Answering technical questions\n• Providing code examples and explanations\n• Recommending learning resources\n\nHow can I assist you today?",
      timestamp: new Date(),
      type: 'text'
    },
  ]);
  
  const [suggestions] = useState([
    'Create a learning path for web development',
    'Explain React hooks with examples',
    'Find Power BI courses for beginners',
    'Help me understand async/await',
  ]);
  
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const [expandedMessage, setExpandedMessage] = useState<number | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    e.target.style.height = 'auto';
    e.target.style.height = `${Math.min(e.target.scrollHeight, 120)}px`;
  };

  const generateAIResponse = async (userInput: string): Promise<Message> => {
    try {
      const { data: { content, type = 'text', metadata = {} } } = await supabase.functions.invoke('ai-assistant', {
        body: { query: userInput }
      });

      return {
        role: 'assistant',
        content,
        type,
        metadata,
        timestamp: new Date()
      };
    } catch (error) {
      console.error('Error generating AI response:', error);
      return {
        role: 'assistant',
        content: "I apologize, but I'm having trouble processing your request right now. Please try again in a moment.",
        type: 'text',
        timestamp: new Date()
      };
    }
  };

  const handleSendMessage = async () => {
    if (!input.trim()) return;
    
    const userMessage: Message = {
      role: 'user',
      content: input.trim(),
      timestamp: new Date(),
      type: 'text'
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
    }
    
    setIsTyping(true);
    
    try {
      const aiResponse = await generateAIResponse(input);
      setMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion);
    if (inputRef.current) {
      inputRef.current.focus();
      inputRef.current.style.height = 'auto';
      inputRef.current.style.height = `${Math.min(inputRef.current.scrollHeight, 120)}px`;
    }
  };

  const renderMessageContent = (message: Message) => {
    switch (message.type) {
      case 'code':
        return (
          <div className="font-mono bg-gray-900 rounded-lg p-4 overflow-x-auto">
            <pre className="text-gray-200">
              <code>{message.content}</code>
            </pre>
          </div>
        );
      case 'course':
        return (
          <div className="grid gap-4">
            {message.metadata.courses.map((course: any, idx: number) => (
              <div
                key={idx}
                className={`p-4 rounded-lg ${
                  theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'
                }`}
              >
                <h4 className="font-medium">{course.title}</h4>
                <p className="text-sm opacity-75 mt-1">{course.description}</p>
                <div className="flex items-center mt-2">
                  <span className="text-sm mr-4">{course.level}</span>
                  <span className="text-sm">{course.duration}</span>
                </div>
              </div>
            ))}
          </div>
        );
      default:
        return (
          <div
            className="prose prose-sm max-w-none"
            dangerouslySetInnerHTML={{
              __html: message.content
                .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
                .replace(/\*(.*?)\*/g, '<em>$1</em>')
                .replace(/\n\n/g, '<br/><br/>')
                .replace(/• (.*?)(?=<br\/>|$)/g, '<div class="flex items-start"><span class="mr-2">•</span><span>$1</span></div>')
            }}
          />
        );
    }
  };

  const getMessageIcon = (message: Message) => {
    if (message.role === 'user') return <User className="w-5 h-5" />;
    
    switch (message.type) {
      case 'code':
        return <Code className="w-5 h-5" />;
      case 'course':
        return <BookOpen className="w-5 h-5" />;
      case 'resource':
        return <FileText className="w-5 h-5" />;
      default:
        return <Bot className="w-5 h-5" />;
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-16rem)]">
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold mb-4">AI Learning Assistant</h1>
        <p className="opacity-75 max-w-2xl mx-auto">
          Your personal AI guide to help you navigate courses, create learning paths, and answer technical questions.
        </p>
      </div>
      
      <div className="flex-1 flex flex-col md:flex-row gap-4 h-full">
        <div className={`flex-1 flex flex-col rounded-xl overflow-hidden border ${
          theme === 'dark' ? 'border-gray-700' : 'border-gray-200'
        }`}>
          <div className={`flex-1 overflow-y-auto p-4 ${
            theme === 'dark' ? 'bg-gray-800' : 'bg-white'
          }`}>
            {messages.map((message, index) => (
              <div
                key={index}
                className={`mb-4 max-w-3xl ${
                  message.role === 'user' ? 'ml-auto' : 'mr-auto'
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    message.role === 'assistant'
                      ? theme === 'dark'
                        ? 'bg-blue-900/30 text-blue-300'
                        : 'bg-blue-100 text-blue-600'
                      : theme === 'dark'
                        ? 'bg-gray-700 text-gray-300'
                        : 'bg-gray-200 text-gray-700'
                  }`}>
                    {getMessageIcon(message)}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center mb-1">
                      <p className="font-medium text-sm">
                        {message.role === 'assistant' ? 'AI Assistant' : 'You'}
                      </p>
                      <span className="text-xs opacity-50 ml-2">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <div className={`p-3 rounded-lg ${
                      message.role === 'assistant'
                        ? theme === 'dark'
                          ? 'bg-gray-700'
                          : 'bg-gray-100'
                        : theme === 'dark'
                          ? 'bg-blue-900/20 text-blue-100'
                          : 'bg-blue-100 text-blue-900'
                    }`}>
                      {renderMessageContent(message)}
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="mb-4 max-w-3xl mr-auto">
                <div className="flex items-start gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    theme === 'dark'
                      ? 'bg-blue-900/30 text-blue-300'
                      : 'bg-blue-100 text-blue-600'
                  }`}>
                    <Bot className="w-5 h-5" />
                  </div>
                  <div className={`p-3 rounded-lg ${
                    theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100'
                  }`}>
                    <div className="flex space-x-1 items-center">
                      <div className="w-2 h-2 rounded-full bg-current animate-pulse"></div>
                      <div className="w-2 h-2 rounded-full bg-current animate-pulse delay-150"></div>
                      <div className="w-2 h-2 rounded-full bg-current animate-pulse delay-300"></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>
          
          <div className={`p-4 border-t ${
            theme === 'dark' ? 'border-gray-700 bg-gray-800' : 'border-gray-200 bg-white'
          }`}>
            <div className="flex flex-col gap-2">
              <div className="flex flex-wrap gap-2 mb-2">
                {suggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    onClick={() => handleSuggestionClick(suggestion)}
                    className={`text-xs px-3 py-1.5 rounded-full flex items-center ${
                      theme === 'dark'
                        ? 'bg-gray-700 hover:bg-gray-600 text-gray-300'
                        : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
                    }`}
                  >
                    <ChevronRight className="w-3 h-3 mr-1" />
                    {suggestion}
                  </button>
                ))}
              </div>
              
              <div className="relative">
                <textarea
                  ref={inputRef}
                  value={input}
                  onChange={handleInputChange}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask me anything about courses, coding, or learning paths..."
                  rows={1}
                  className={`w-full px-4 py-3 pr-12 rounded-lg resize-none ${
                    theme === 'dark'
                      ? 'bg-gray-700 text-white border-gray-600'
                      : 'bg-gray-100 text-gray-900 border-gray-300'
                  } border focus:ring-2 focus:ring-blue-500 focus:border-transparent focus:outline-none`}
                  style={{ minHeight: '44px', maxHeight: '120px' }}
                />
                <button
                  onClick={handleSendMessage}
                  disabled={!input.trim()}
                  className={`absolute right-2 bottom-2 p-2 rounded-lg ${
                    input.trim()
                      ? theme === 'dark'
                        ? 'bg-blue-600 hover:bg-blue-700 text-white'
                        : 'bg-blue-600 hover:bg-blue-700 text-white'
                      : theme === 'dark'
                        ? 'bg-gray-600 text-gray-400'
                        : 'bg-gray-200 text-gray-400'
                  } transition-colors`}
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div className="md:w-72 space-y-4">
          <div className={`p-4 rounded-xl ${
            theme === 'dark' ? 'bg-blue-900/20' : 'bg-blue-50'
          }`}>
            <div className="flex items-center mb-2">
              <Sparkles className={`w-5 h-5 mr-2 ${
                theme === 'dark' ? 'text-blue-300' : 'text-blue-600'
              }`} />
              <h3 className="font-medium">Course Recommendations</h3>
            </div>
            <p className="text-sm opacity-75 mb-2">
              Get personalized course suggestions based on your interests and goals.
            </p>
            <button
              onClick={() => handleSuggestionClick("Recommend courses based on my interests")}
              className="text-xs flex items-center text-blue-500 hover:underline"
            >
              <CornerDownRight className="w-3 h-3 mr-1" /> Ask for recommendations
            </button>
          </div>
          
          <div className={`p-4 rounded-xl ${
            theme === 'dark' ? 'bg-purple-900/20' : 'bg-purple-50'
          }`}>
            <div className="flex items-center mb-2">
              <Brain className={`w-5 h-5 mr-2 ${
                theme === 'dark' ? 'text-purple-300' : 'text-purple-600'
              }`} />
              <h3 className="font-medium">Learning Paths</h3>
            </div>
            <p className="text-sm opacity-75 mb-2">
              Get a structured roadmap to achieve your learning goals efficiently.
            </p>
            <button
              onClick={() => handleSuggestionClick("Create a learning path for me")}
              className="text-xs flex items-center text-blue-500 hover:underline"
            >
              <CornerDownRight className="w-3 h-3 mr-1" /> Request a learning path
            </button>
          </div>
          
          <div className={`p-4 rounded-xl ${
            theme === 'dark' ? 'bg-green-900/20' : 'bg-green-50'
          }`}>
            <div className="flex items-center mb-2">
              <Bot className={`w-5 h-5 mr-2 ${
                theme === 'dark' ? 'text-green-300' : 'text-green-600'
              }`} />
              <h3 className="font-medium">Technical Help</h3>
            </div>
            <p className="text-sm opacity-75 mb-2">
              Get help with coding problems, technical concepts, and implementation details.
            </p>
            <button
              onClick={() => handleSuggestionClick("Help me understand a technical concept")}
              className="text-xs flex items-center text-blue-500 hover:underline"
            >
              <CornerDownRight className="w-3 h-3 mr-1" /> Ask for help
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AiAssistantPage;