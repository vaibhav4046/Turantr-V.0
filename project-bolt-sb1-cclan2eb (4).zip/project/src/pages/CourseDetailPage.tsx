import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Calendar, Clock, BookOpen, Award, PlayCircle, FileText, CheckCircle, ChevronDown, ChevronUp, ArrowLeft } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { allCourses } from '../data/courses';

interface CourseDetailPageProps {
  selectedCourse: any;
}

const CourseDetailPage: React.FC<CourseDetailPageProps> = ({ selectedCourse }) => {
  const { theme } = useTheme();
  const { courseId } = useParams<{ courseId: string }>();
  const [course, setCourse] = useState<any>(null);
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({});
  const [activeTab, setActiveTab] = useState<'content' | 'description' | 'reviews'>('content');

  // Set the course based on the URL parameter or the selected course
  useEffect(() => {
    if (selectedCourse) {
      setCourse(selectedCourse);
    } else if (courseId) {
      const foundCourse = allCourses.find(c => c.id.toString() === courseId);
      if (foundCourse) setCourse(foundCourse);
    }
  }, [courseId, selectedCourse]);

  if (!course) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-center">
          <h2 className="text-xl font-semibold mb-2">Loading course...</h2>
          <p>If the course doesn't load, it may not exist.</p>
          <Link to="/courses" className="mt-4 inline-block text-blue-500 hover:underline">
            Return to courses
          </Link>
        </div>
      </div>
    );
  }

  const toggleSection = (sectionId: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [sectionId]: !prev[sectionId]
    }));
  };

  const getLevelColor = (level: string) => {
    if (theme === 'dark') {
      switch (level) {
        case 'Beginner': return 'bg-green-900/20 text-green-300';
        case 'Intermediate': return 'bg-yellow-900/20 text-yellow-300';
        case 'Advanced': return 'bg-red-900/20 text-red-300';
        default: return 'bg-blue-900/20 text-blue-300';
      }
    } else {
      switch (level) {
        case 'Beginner': return 'bg-green-100 text-green-800';
        case 'Intermediate': return 'bg-yellow-100 text-yellow-800';
        case 'Advanced': return 'bg-red-100 text-red-800';
        default: return 'bg-blue-100 text-blue-800';
      }
    }
  };

  return (
    <div>
      <Link to="/courses" className="flex items-center text-blue-500 hover:underline mb-6">
        <ArrowLeft className="w-4 h-4 mr-1" /> Back to courses
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Course Info */}
        <div className="lg:col-span-2">
          <div className={`overflow-hidden rounded-xl ${
            theme === 'dark' ? 'bg-gray-800' : 'bg-white'
          } shadow-sm`}>
            {/* Course Header Image */}
            <div className="h-64 overflow-hidden relative">
              <img 
                src={course.image} 
                alt={course.title} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex flex-col justify-end p-6">
                <div className="flex flex-wrap gap-2 mb-3">
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${getLevelColor(course.level)}`}>
                    {course.level}
                  </span>
                  <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-medium ${
                    theme === 'dark' ? 'bg-blue-900/20 text-blue-300' : 'bg-blue-100 text-blue-800'
                  }`}>
                    {course.category}
                  </span>
                </div>
                <h1 className="text-2xl md:text-3xl font-bold text-white">{course.title}</h1>
              </div>
            </div>

            {/* Course Info */}
            <div className="p-6">
              <div className="flex flex-wrap gap-6 mb-6">
                <div className="flex items-center">
                  <Calendar className="w-5 h-5 mr-2 opacity-70" />
                  <span>Updated {course.updatedAt}</span>
                </div>
                <div className="flex items-center">
                  <Clock className="w-5 h-5 mr-2 opacity-70" />
                  <span>{course.duration}</span>
                </div>
                <div className="flex items-center">
                  <BookOpen className="w-5 h-5 mr-2 opacity-70" />
                  <span>{course.modules.length} modules</span>
                </div>
              </div>

              {/* Tabs */}
              <div className="border-b mb-6">
                <div className="flex space-x-8">
                  {(['content', 'description', 'reviews'] as const).map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveTab(tab)}
                      className={`py-3 border-b-2 font-medium text-sm transition-colors ${
                        activeTab === tab
                          ? `border-blue-500 ${theme === 'dark' ? 'text-blue-300' : 'text-blue-600'}`
                          : `border-transparent ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'} hover:text-gray-700`
                      }`}
                    >
                      {tab.charAt(0).toUpperCase() + tab.slice(1)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Tab Content */}
              <div>
                {activeTab === 'content' && (
                  <div className="space-y-6">
                    <h2 className="text-lg font-semibold mb-4">Course Content</h2>
                    
                    {course.modules.map((module: any, idx: number) => (
                      <div
                        key={idx}
                        className={`border rounded-lg overflow-hidden ${
                          theme === 'dark' ? 'border-gray-700' : 'border-gray-200'
                        }`}
                      >
                        {/* Module Header */}
                        <button
                          onClick={() => toggleSection(`module-${idx}`)}
                          className={`w-full p-4 flex items-center justify-between ${
                            theme === 'dark' ? 'bg-gray-700/50' : 'bg-gray-50'
                          }`}
                        >
                          <span className="font-medium flex items-center">
                            <span className={`w-6 h-6 rounded-full inline-flex items-center justify-center mr-2 text-xs ${
                              theme === 'dark' ? 'bg-gray-900 text-gray-300' : 'bg-gray-200 text-gray-700'
                            }`}>
                              {idx + 1}
                            </span>
                            {module.title}
                          </span>
                          {expandedSections[`module-${idx}`] ? (
                            <ChevronUp className="w-5 h-5" />
                          ) : (
                            <ChevronDown className="w-5 h-5" />
                          )}
                        </button>
                        
                        {/* Module Content */}
                        {expandedSections[`module-${idx}`] && (
                          <div className="p-4 space-y-2">
                            {module.lessons.map((lesson: any, lessonIdx: number) => (
                              <div
                                key={lessonIdx}
                                className={`p-3 rounded-md flex items-center ${
                                  theme === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-100'
                                }`}
                              >
                                {lesson.type === 'video' ? (
                                  <PlayCircle className="w-5 h-5 mr-3 flex-shrink-0" />
                                ) : (
                                  <FileText className="w-5 h-5 mr-3 flex-shrink-0" />
                                )}
                                <div className="flex-grow">
                                  <p className="text-sm">{lesson.title}</p>
                                  <p className="text-xs opacity-70">{lesson.duration}</p>
                                </div>
                                {lesson.preview && (
                                  <span className={`text-xs px-2 py-1 rounded ${
                                    theme === 'dark' ? 'bg-blue-900/20 text-blue-300' : 'bg-blue-100 text-blue-700'
                                  }`}>
                                    Preview
                                  </span>
                                )}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
                
                {activeTab === 'description' && (
                  <div>
                    <h2 className="text-lg font-semibold mb-4">Course Description</h2>
                    <div className="space-y-4">
                      <p>{course.description}</p>
                      <p>This course is perfect for {course.forWhom}.</p>
                      
                      <h3 className="font-semibold mt-6">What You'll Learn</h3>
                      <ul className="space-y-2 list-inside list-disc">
                        {course.whatYouWillLearn.map((item: string, idx: number) => (
                          <li key={idx} className="flex items-start">
                            <CheckCircle className="w-5 h-5 mr-2 flex-shrink-0 text-green-500" />
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                      
                      <h3 className="font-semibold mt-6">Prerequisites</h3>
                      <p>{course.prerequisites || 'No prior knowledge required.'}</p>
                    </div>
                  </div>
                )}
                
                {activeTab === 'reviews' && (
                  <div>
                    <h2 className="text-lg font-semibold mb-4">Student Reviews</h2>
                    
                    <div className="flex items-center mb-6">
                      <div className="mr-4">
                        <div className="text-4xl font-bold">{course.rating}</div>
                        <div className="flex text-yellow-400">
                          {[...Array(5)].map((_, i) => (
                            <svg key={i} className="w-5 h-5 fill-current" viewBox="0 0 20 20">
                              <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                            </svg>
                          ))}
                        </div>
                        <div className="text-sm opacity-70">{course.reviewCount} reviews</div>
                      </div>
                      
                      <div className="flex-grow">
                        {[5, 4, 3, 2, 1].map(stars => {
                          const percentage = Math.round(Math.random() * 100);
                          return (
                            <div key={stars} className="flex items-center mb-1">
                              <div className="text-sm w-10">{stars} stars</div>
                              <div className="flex-grow mx-3 bg-gray-200 rounded-full h-2">
                                <div
                                  className="bg-yellow-400 h-2 rounded-full"
                                  style={{ width: `${percentage}%` }}
                                ></div>
                              </div>
                              <div className="text-xs w-10">{percentage}%</div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                    
                    <div className="space-y-6">
                      {Array.from({ length: 3 }).map((_, idx) => {
                        const names = ['Alex Johnson', 'Sarah Williams', 'Michael Chen'];
                        const contents = [
                          'This course exceeded my expectations. The content is up-to-date and very practical.',
                          'I loved how the AI tutor adapted to my learning style. The interactive exercises were especially helpful.',
                          'Great course structure! The bite-sized lessons made it easy to learn even with my busy schedule.'
                        ];
                        const dates = ['2 weeks ago', '1 month ago', '3 months ago'];
                        
                        return (
                          <div key={idx} className={`p-4 rounded-lg ${
                            theme === 'dark' ? 'bg-gray-700/30' : 'bg-gray-50'
                          }`}>
                            <div className="flex items-start">
                              <div className={`w-10 h-10 rounded-full ${
                                theme === 'dark' ? 'bg-gray-600' : 'bg-gray-300'
                              } flex items-center justify-center font-medium text-lg mr-3`}>
                                {names[idx].charAt(0)}
                              </div>
                              <div className="flex-grow">
                                <div className="flex items-center justify-between">
                                  <h4 className="font-medium">{names[idx]}</h4>
                                  <span className="text-xs opacity-70">{dates[idx]}</span>
                                </div>
                                <div className="flex text-yellow-400 my-1">
                                  {[...Array(5)].map((_, i) => (
                                    <svg key={i} className="w-4 h-4 fill-current" viewBox="0 0 20 20">
                                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                                    </svg>
                                  ))}
                                </div>
                                <p className="mt-2 text-sm">{contents[idx]}</p>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        
        {/* Enrollment Card */}
        <div className="lg:col-span-1">
          <div className={`p-6 rounded-xl sticky top-24 ${
            theme === 'dark' ? 'bg-gray-800' : 'bg-white'
          } shadow-sm`}>
            <div className="text-center mb-6">
              <p className="text-3xl font-bold">{course.price === 'Free' ? 'Free' : `$${course.price}`}</p>
              <button
                className={`w-full py-3 px-4 mt-4 rounded-lg font-medium ${
                  theme === 'dark'
                    ? 'bg-blue-600 hover:bg-blue-700 text-white'
                    : 'bg-blue-600 hover:bg-blue-700 text-white'
                } transition-colors`}
              >
                Enroll Now
              </button>
              <p className="mt-2 text-sm opacity-70">30-Day Money-Back Guarantee</p>
            </div>
            
            <div className="space-y-4">
              <h3 className="font-semibold">This course includes:</h3>
              <ul className="space-y-3">
                {[
                  { icon: <PlayCircle className="w-5 h-5" />, text: `${course.videoHours} hours of video content` },
                  { icon: <FileText className="w-5 h-5" />, text: `${course.resources} downloadable resources` },
                  { icon: <BookOpen className="w-5 h-5" />, text: 'Full lifetime access' },
                  { icon: <Award className="w-5 h-5" />, text: 'Certificate of completion' },
                ].map((item, idx) => (
                  <li key={idx} className="flex items-center">
                    <span className="mr-3 opacity-70">{item.icon}</span>
                    <span className="text-sm">{item.text}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="mt-6 pt-6 border-t">
              <h3 className="font-semibold mb-3">Share this course</h3>
              <div className="flex space-x-3">
                {['Facebook', 'Twitter', 'LinkedIn'].map((platform) => (
                  <button
                    key={platform}
                    className={`px-3 py-2 rounded-md text-sm ${
                      theme === 'dark'
                        ? 'bg-gray-700 hover:bg-gray-600'
                        : 'bg-gray-100 hover:bg-gray-200'
                    } transition-colors`}
                  >
                    {platform}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetailPage;