import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Filter, X } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import CourseCard from '../components/course/CourseCard';
import { allCourses } from '../data/courses';

interface CoursesPageProps {
  setSelectedCourse: (course: any) => void;
}

const CoursesPage: React.FC<CoursesPageProps> = ({ setSelectedCourse }) => {
  const { theme } = useTheme();
  const navigate = useNavigate();
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedLevel, setSelectedLevel] = useState<string>('');
  const [filtersOpen, setFiltersOpen] = useState(false);
  
  const categories = ['Web Development', 'Data Science', 'Business', 'Design', 'Marketing', 'No-Code', 'Zoho', 'Tally', 'Power BI'];
  const levels = ['Beginner', 'Intermediate', 'Advanced'];
  
  // Filter courses based on search query, category, and level
  const filteredCourses = allCourses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          course.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory ? course.category === selectedCategory : true;
    const matchesLevel = selectedLevel ? course.level === selectedLevel : true;
    
    return matchesSearch && matchesCategory && matchesLevel;
  });
  
  const handleCourseClick = (course: any) => {
    setSelectedCourse(course);
    navigate(`/courses/${course.id}`);
  };
  
  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('');
    setSelectedLevel('');
  };
  
  return (
    <div className="space-y-8">
      <div className="text-center max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-4">Explore Our Course Library</h1>
        <p className="opacity-75">
          Discover AI-powered courses tailored to your learning needs and goals.
          Filter by category, difficulty level, or search for specific topics.
        </p>
      </div>
      
      {/* Search and Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className={`relative flex-grow ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 opacity-50" />
          </div>
          <input
            type="text"
            placeholder="Search for courses..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`pl-10 pr-4 py-3 w-full rounded-lg ${
              theme === 'dark'
                ? 'bg-gray-800 border-gray-700 focus:border-blue-500'
                : 'bg-white border-gray-300 focus:border-blue-500'
            } border focus:ring-1 focus:ring-blue-500 focus:outline-none`}
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3 flex items-center"
            >
              <X className="h-5 w-5 opacity-50 hover:opacity-100" />
            </button>
          )}
        </div>
        
        <button
          onClick={() => setFiltersOpen(!filtersOpen)}
          className={`md:hidden px-4 py-3 rounded-lg flex items-center justify-center gap-2 ${
            theme === 'dark'
              ? 'bg-gray-800 text-white border-gray-700'
              : 'bg-white text-gray-800 border-gray-300'
          } border`}
        >
          <Filter className="h-5 w-5" />
          {filtersOpen ? 'Hide Filters' : 'Show Filters'}
        </button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Filters Sidebar - Desktop (persistent) and Mobile (toggleable) */}
        <div className={`lg:block ${filtersOpen ? 'block' : 'hidden'}`}>
          <div className={`p-6 rounded-xl ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'} shadow-sm`}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-semibold text-lg">Filters</h2>
              {(selectedCategory || selectedLevel) && (
                <button
                  onClick={clearFilters}
                  className="text-sm text-blue-500 hover:underline flex items-center"
                >
                  Clear all <X className="ml-1 h-3 w-3" />
                </button>
              )}
            </div>
            
            {/* Categories */}
            <div className="mb-6">
              <h3 className={`font-medium mb-3 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>Categories</h3>
              <div className="space-y-2">
                {categories.map(category => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(selectedCategory === category ? '' : category)}
                    className={`block px-3 py-2 text-sm rounded-lg w-full text-left transition-colors ${
                      selectedCategory === category
                        ? theme === 'dark'
                          ? 'bg-blue-900/30 text-blue-300'
                          : 'bg-blue-100 text-blue-700'
                        : theme === 'dark'
                          ? 'hover:bg-gray-700'
                          : 'hover:bg-gray-100'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Difficulty Levels */}
            <div>
              <h3 className={`font-medium mb-3 ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>Difficulty Level</h3>
              <div className="space-y-2">
                {levels.map(level => (
                  <button
                    key={level}
                    onClick={() => setSelectedLevel(selectedLevel === level ? '' : level)}
                    className={`block px-3 py-2 text-sm rounded-lg w-full text-left transition-colors ${
                      selectedLevel === level
                        ? theme === 'dark'
                          ? 'bg-blue-900/30 text-blue-300'
                          : 'bg-blue-100 text-blue-700'
                        : theme === 'dark'
                          ? 'hover:bg-gray-700'
                          : 'hover:bg-gray-100'
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
        
        {/* Course Grid */}
        <div className="lg:col-span-3">
          {/* Active filters */}
          {(selectedCategory || selectedLevel) && (
            <div className="flex flex-wrap gap-2 mb-4">
              {selectedCategory && (
                <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm ${
                  theme === 'dark' ? 'bg-blue-900/20 text-blue-300' : 'bg-blue-100 text-blue-800'
                }`}>
                  Category: {selectedCategory}
                  <button
                    onClick={() => setSelectedCategory('')}
                    className="ml-2"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              )}
              
              {selectedLevel && (
                <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm ${
                  theme === 'dark' ? 'bg-blue-900/20 text-blue-300' : 'bg-blue-100 text-blue-800'
                }`}>
                  Level: {selectedLevel}
                  <button
                    onClick={() => setSelectedLevel('')}
                    className="ml-2"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              )}
            </div>
          )}
          
          {filteredCourses.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredCourses.map((course) => (
                <div
                  key={course.id}
                  onClick={() => handleCourseClick(course)}
                  className="cursor-pointer"
                >
                  <CourseCard course={course} />
                </div>
              ))}
            </div>
          ) : (
            <div className={`text-center py-12 px-4 rounded-xl ${
              theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'
            }`}>
              <p className="text-lg mb-2">No courses match your search criteria</p>
              <p className="opacity-75">Try adjusting your filters or search terms</p>
              <button
                onClick={clearFilters}
                className={`mt-4 px-4 py-2 rounded-lg ${
                  theme === 'dark'
                    ? 'bg-blue-600 hover:bg-blue-700'
                    : 'bg-blue-600 hover:bg-blue-700'
                } text-white transition-colors`}
              >
                Clear all filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CoursesPage;