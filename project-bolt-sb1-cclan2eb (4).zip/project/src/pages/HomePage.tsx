import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Trophy, Brain, ArrowRight, MessageSquareText, Sparkles } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import CourseCard from '../components/course/CourseCard';
import { featuredCourses } from '../data/courses';

const HomePage: React.FC = () => {
  const { theme } = useTheme();

  return (
    <div className="space-y-20">
      {/* Hero Section */}
      <section className="relative py-20 px-4 md:px-6 rounded-3xl overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 opacity-90 rounded-3xl"></div>
        <div className="absolute inset-0 bg-[url('https://images.pexels.com/photos/7321576/pexels-photo-7321576.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2')] bg-cover bg-center bg-no-repeat mix-blend-overlay opacity-20 rounded-3xl"></div>
        
        <div className="relative max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
            <span className="block">Transform Your Skills with</span>
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-amber-200 to-yellow-300">AI-Powered Learning</span>
          </h1>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Discover personalized courses, adaptive learning paths, and an AI assistant that evolves with your progress.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              to="/courses"
              className="px-8 py-3 bg-white text-blue-700 font-medium rounded-full hover:bg-blue-50 transition-colors duration-300 flex items-center justify-center gap-2"
            >
              <BookOpen className="w-5 h-5" />
              Explore Courses
            </Link>
            <Link
              to="/ai-assistant"
              className="px-8 py-3 bg-blue-900/30 backdrop-blur-sm text-white border border-white/20 font-medium rounded-full hover:bg-blue-900/50 transition-colors duration-300 flex items-center justify-center gap-2"
            >
              <MessageSquareText className="w-5 h-5" />
              Talk to AI Assistant
            </Link>
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-16 text-white">
            {[
              { label: 'Courses', value: '300+' },
              { label: 'Students', value: '15,000+' },
              { label: 'Completion Rate', value: '94%' },
              { label: 'AI-Generated Content', value: '100%' },
            ].map((stat, index) => (
              <div key={index} className="p-4 rounded-xl bg-white/10 backdrop-blur-sm">
                <p className="text-3xl font-bold">{stat.value}</p>
                <p className="text-sm opacity-80">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-12">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">How Turantr Works</h2>
          <p className="text-lg opacity-75 max-w-2xl mx-auto">
            Our platform combines AI-generated content with personalized learning paths to provide you with the most effective learning experience.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: <Brain className="w-10 h-10" />,
              title: 'AI-Generated Courses',
              description: 'Courses crafted by AI to ensure up-to-date content across various topics and skill levels.',
            },
            {
              icon: <Sparkles className="w-10 h-10" />,
              title: 'Personalized Learning',
              description: 'Custom learning paths based on your interests, goals, and previous knowledge.',
            },
            {
              icon: <Trophy className="w-10 h-10" />,
              title: 'Skill Certification',
              description: 'Earn AI-certified credentials upon successfully completing courses and assessments.',
            },
          ].map((feature, index) => (
            <div 
              key={index} 
              className={`p-8 rounded-2xl transition-all duration-300 ${
                theme === 'dark' 
                  ? 'bg-gray-800 hover:bg-gray-800/80' 
                  : 'bg-white hover:bg-blue-50'
              } hover:shadow-lg group`}
            >
              <div className={`mb-6 p-4 rounded-xl inline-block ${
                theme === 'dark' ? 'bg-blue-900/30 text-blue-300' : 'bg-blue-100 text-blue-600'
              }`}>
                {feature.icon}
              </div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="opacity-75 mb-4">{feature.description}</p>
              <Link 
                to="/courses" 
                className={`flex items-center text-sm font-medium ${
                  theme === 'dark' ? 'text-blue-300' : 'text-blue-600'
                } group-hover:underline`}
              >
                Learn more <ArrowRight className="ml-1 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Courses */}
      <section>
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-bold">Featured Courses</h2>
          <Link 
            to="/courses" 
            className={`flex items-center text-sm font-medium ${
              theme === 'dark' ? 'text-blue-300' : 'text-blue-600'
            } hover:underline`}
          >
            View all courses <ArrowRight className="ml-1 w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuredCourses.map((course) => (
            <CourseCard key={course.id} course={course} />
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className={`py-12 px-4 rounded-3xl ${
        theme === 'dark' ? 'bg-gray-800/50' : 'bg-blue-50'
      }`}>
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold mb-4">What Our Learners Say</h2>
          <p className="text-lg opacity-75 max-w-2xl mx-auto">
            Join thousands of satisfied learners who have transformed their skills with Turantr.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              name: 'Alex Johnson',
              role: 'Software Developer',
              image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
              quote: 'The AI-generated courses are incredibly relevant and up-to-date. I learned more in 2 weeks than in months of traditional courses.',
            },
            {
              name: 'Sarah Chen',
              role: 'Marketing Specialist',
              image: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
              quote: 'The personalized learning paths helped me focus on exactly what I needed to know, saving me countless hours.',
            },
            {
              name: 'Michael Rodriguez',
              role: 'Business Analyst',
              image: 'https://images.pexels.com/photos/2379005/pexels-photo-2379005.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
              quote: 'The AI assistant is like having a tutor available 24/7. It clarified my doubts instantly and kept me motivated.',
            },
          ].map((testimonial, index) => (
            <div 
              key={index} 
              className={`p-6 rounded-xl ${
                theme === 'dark' ? 'bg-gray-900' : 'bg-white'
              } shadow-md`}
            >
              <div className="flex items-center mb-4">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name} 
                  className="w-12 h-12 rounded-full object-cover mr-4"
                />
                <div>
                  <h4 className="font-semibold">{testimonial.name}</h4>
                  <p className="text-sm opacity-75">{testimonial.role}</p>
                </div>
              </div>
              <p className={`italic ${theme === 'dark' ? 'text-gray-300' : 'text-gray-600'}`}>
                "{testimonial.quote}"
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="text-center py-16">
        <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Learning?</h2>
        <p className="text-lg opacity-75 max-w-2xl mx-auto mb-8">
          Join our AI-powered learning platform today and gain access to personalized courses,
          expert guidance, and a community of learners.
        </p>
        <Link
          to="/courses"
          className={`px-8 py-3 font-medium rounded-full inline-flex items-center ${
            theme === 'dark' 
              ? 'bg-blue-600 hover:bg-blue-700 text-white' 
              : 'bg-blue-600 hover:bg-blue-700 text-white'
          } transition-colors duration-300`}
        >
          Start Learning Now <ArrowRight className="ml-2 w-5 h-5" />
        </Link>
      </section>
    </div>
  );
};

export default HomePage;