import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BarChart3, BookOpen, Clock, CheckCircle, Award, BookMarked, Settings, LayoutGrid, List, Search } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';
import { allCourses } from '../data/courses';
import ProgressChart from '../components/dashboard/ProgressChart';
import SkillsRadarChart from '../components/dashboard/SkillsRadarChart';

const DashboardPage: React.FC = () => {
  const { theme } = useTheme();
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [activeTab, setActiveTab] = useState<'in-progress' | 'completed' | 'wishlist'>('in-progress');
  
  // Mock user data
  const user = {
    name: 'Alex Johnson',
    email: 'alex@example.com',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    streak: 12,
    totalHoursLearned: 47,
    coursesCompleted: 4,
  };
  
  // Mocked enrolled courses data
  const myCourses = {
    'in-progress': allCourses.slice(0, 3).map(course => ({
      ...course,
      progress: Math.floor(Math.random() * 85) + 15,
      lastAccessed: ['Yesterday', '3 days ago', '1 week ago'][Math.floor(Math.random() * 3)],
    })),
    'completed': allCourses.slice(3, 5).map(course => ({
      ...course,
      progress: 100,
      completedDate: ['2 weeks ago', '1 month ago'][Math.floor(Math.random() * 2)],
    })),
    'wishlist': allCourses.slice(5, 7),
  };
  
  const tabCounts = {
    'in-progress': myCourses['in-progress'].length,
    'completed': myCourses['completed'].length,
    'wishlist': myCourses['wishlist'].length,
  };

  const renderCourseItem = (course: any) => {
    if (viewMode === 'grid') {
      return (
        <div 
          className={`rounded-xl overflow-hidden shadow-sm ${
            theme === 'dark' ? 'bg-gray-800' : 'bg-white'
          }`}
        >
          <div className="h-40 overflow-hidden relative">
            <img 
              src={course.image} 
              alt={course.title} 
              className="w-full h-full object-cover"
            />
            {activeTab === 'in-progress' && (
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-300">
                <div 
                  className="h-1 bg-blue-500" 
                  style={{ width: `${course.progress}%` }}
                ></div>
              </div>
            )}
          </div>
          <div className="p-4">
            <h3 className="font-medium mb-1 line-clamp-1">{course.title}</h3>
            <p className="text-sm opacity-75 mb-3">{course.instructor}</p>
            
            {activeTab === 'in-progress' && (
              <div className="flex justify-between items-center">
                <span className="text-sm">{course.progress}% complete</span>
                <span className="text-xs opacity-70">Last: {course.lastAccessed}</span>
              </div>
            )}
            
            {activeTab === 'completed' && (
              <div className="flex justify-between items-center">
                <span className={`text-sm ${theme === 'dark' ? 'text-green-300' : 'text-green-600'} flex items-center`}>
                  <CheckCircle className="w-4 h-4 mr-1" /> Completed
                </span>
                <span className="text-xs opacity-70">
                  {course.completedDate}
                </span>
              </div>
            )}
            
            {activeTab === 'wishlist' && (
              <div className="flex justify-between items-center">
                <span className="text-sm">{course.level}</span>
                <span className="text-sm font-medium">
                  {course.price === 'Free' ? 'Free' : `$${course.price}`}
                </span>
              </div>
            )}
          </div>
        </div>
      );
    }
    
    return (
      <div
        className={`p-4 rounded-xl ${
          theme === 'dark' ? 'bg-gray-800 hover:bg-gray-700' : 'bg-white hover:bg-gray-50'
        } transition-colors flex gap-4`}
      >
        <img 
          src={course.image} 
          alt={course.title} 
          className="w-20 h-20 object-cover rounded-lg"
        />
        <div className="flex-grow">
          <h3 className="font-medium mb-1">{course.title}</h3>
          <p className="text-sm opacity-75 mb-2">{course.instructor}</p>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center text-xs">
              <BookOpen className="w-4 h-4 mr-1 opacity-70" />
              {course.modules.length} modules
            </div>
            <div className="flex items-center text-xs">
              <Clock className="w-4 h-4 mr-1 opacity-70" />
              {course.duration}
            </div>
          </div>
        </div>
        
        <div className="flex flex-col items-end justify-between">
          {activeTab === 'in-progress' && (
            <>
              <span className="text-sm">{course.progress}%</span>
              <div className="w-20 h-2 bg-gray-200 rounded-full overflow-hidden mt-2">
                <div 
                  className="h-2 bg-blue-500 rounded-full" 
                  style={{ width: `${course.progress}%` }}
                ></div>
              </div>
              <span className="text-xs opacity-70 mt-1">
                Last: {course.lastAccessed}
              </span>
            </>
          )}
          
          {activeTab === 'completed' && (
            <>
              <span className={`text-sm ${theme === 'dark' ? 'text-green-300' : 'text-green-600'} flex items-center`}>
                <CheckCircle className="w-4 h-4 mr-1" /> Completed
              </span>
              <span className="text-xs opacity-70 mt-1">
                {course.completedDate}
              </span>
            </>
          )}
          
          {activeTab === 'wishlist' && (
            <>
              <span className="text-sm font-medium">
                {course.price === 'Free' ? 'Free' : `$${course.price}`}
              </span>
              <button
                className={`mt-2 text-sm px-3 py-1 rounded-full ${
                  theme === 'dark'
                    ? 'bg-blue-600 hover:bg-blue-700 text-white'
                    : 'bg-blue-600 hover:bg-blue-700 text-white'
                }`}
              >
                Enroll
              </button>
            </>
          )}
        </div>
      </div>
    );
  };
  
  return (
    <div className="space-y-10">
      {/* Dashboard Header */}
      <div className={`p-6 rounded-2xl ${
        theme === 'dark' ? 'bg-gray-800' : 'bg-white'
      }`}>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full overflow-hidden">
              <img 
                src={user.avatar} 
                alt={user.name} 
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h1 className="text-2xl font-bold">{user.name}</h1>
              <p className="opacity-70">{user.email}</p>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-6">
            <div className="text-center">
              <p className="text-sm opacity-75">Learning Streak</p>
              <p className="text-xl font-bold">{user.streak} days</p>
            </div>
            <div className="text-center">
              <p className="text-sm opacity-75">Hours Learned</p>
              <p className="text-xl font-bold">{user.totalHoursLearned} hrs</p>
            </div>
            <div className="text-center">
              <p className="text-sm opacity-75">Courses Completed</p>
              <p className="text-xl font-bold">{user.coursesCompleted}</p>
            </div>
            <Link
              to="#"
              className={`flex items-center gap-1 text-sm px-4 py-2 rounded-full border ${
                theme === 'dark'
                  ? 'border-gray-700 hover:bg-gray-700'
                  : 'border-gray-300 hover:bg-gray-100'
              }`}
            >
              <Settings className="w-4 h-4" /> Profile Settings
            </Link>
          </div>
        </div>
      </div>
      
      {/* Analytics Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Learning Progress */}
        <div className={`p-6 rounded-xl ${
          theme === 'dark' ? 'bg-gray-800' : 'bg-white'
        }`}>
          <h2 className="text-lg font-semibold mb-4 flex items-center">
            <BarChart3 className="w-5 h-5 mr-2 opacity-75" /> Learning Progress
          </h2>
          <ProgressChart theme={theme} />
        </div>
        
        {/* Skills Overview */}
        <div className={`p-6 rounded-xl ${
          theme === 'dark' ? 'bg-gray-800' : 'bg-white'
        }`}>
          <h2 className="text-lg font-semibold mb-4 flex items-center">
            <BookMarked className="w-5 h-5 mr-2 opacity-75" /> Skills Overview
          </h2>
          <div className="h-64">
            <SkillsRadarChart theme={theme} />
          </div>
        </div>
      </div>
      
      {/* My Courses Section */}
      <div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <h2 className="text-2xl font-bold">My Courses</h2>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <div className={`relative ${theme === 'dark' ? 'text-white' : 'text-gray-800'}`}>
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 opacity-50" />
              </div>
              <input
                type="text"
                placeholder="Search your courses..."
                className={`pl-9 pr-4 py-2 w-full rounded-lg text-sm ${
                  theme === 'dark'
                    ? 'bg-gray-800 border-gray-700 focus:border-blue-500'
                    : 'bg-white border-gray-300 focus:border-blue-500'
                } border focus:ring-1 focus:ring-blue-500 focus:outline-none`}
              />
            </div>
            
            <div className={`flex rounded-lg overflow-hidden border ${
              theme === 'dark' ? 'border-gray-700' : 'border-gray-300'
            }`}>
              <button
                onClick={() => setViewMode('grid')}
                className={`p-2 ${
                  viewMode === 'grid'
                    ? theme === 'dark'
                      ? 'bg-gray-700 text-white'
                      : 'bg-gray-200 text-gray-800'
                    : ''
                }`}
              >
                <LayoutGrid className="w-5 h-5" />
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`p-2 ${
                  viewMode === 'list'
                    ? theme === 'dark'
                      ? 'bg-gray-700 text-white'
                      : 'bg-gray-200 text-gray-800'
                    : ''
                }`}
              >
                <List className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
        
        {/* Course Tabs */}
        <div className="mb-6 border-b">
          <div className="flex space-x-6">
            {(['in-progress', 'completed', 'wishlist'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-3 border-b-2 font-medium text-sm transition-colors flex items-center ${
                  activeTab === tab
                    ? `border-blue-500 ${theme === 'dark' ? 'text-blue-300' : 'text-blue-600'}`
                    : `border-transparent ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'} hover:text-gray-700`
                }`}
              >
                {tab === 'in-progress' && <Clock className="w-4 h-4 mr-2" />}
                {tab === 'completed' && <CheckCircle className="w-4 h-4 mr-2" />}
                {tab === 'wishlist' && <BookMarked className="w-4 h-4 mr-2" />}
                {tab.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${
                  theme === 'dark' ? 'bg-gray-700' : 'bg-gray-200'
                }`}>
                  {tabCounts[tab]}
                </span>
              </button>
            ))}
          </div>
        </div>
        
        {/* Course List */}
        {myCourses[activeTab].length > 0 ? (
          <div className={`grid gap-6 ${
            viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1'
          }`}>
            {myCourses[activeTab].map((course) => (
              <Link key={course.id} to={`/courses/${course.id}`}>
                {renderCourseItem(course)}
              </Link>
            ))}
          </div>
        ) : (
          <div className={`text-center py-12 px-4 rounded-xl ${
            theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'
          }`}>
            <p className="mb-2">You don't have any {activeTab.replace('-', ' ')} courses yet</p>
            <Link
              to="/courses"
              className={`px-4 py-2 rounded-lg mt-4 inline-block ${
                theme === 'dark'
                  ? 'bg-blue-600 hover:bg-blue-700'
                  : 'bg-blue-600 hover:bg-blue-700'
              } text-white transition-colors`}
            >
              Browse courses
            </Link>
          </div>
        )}
      </div>
      
      {/* Certificates Section */}
      <div>
        <h2 className="text-2xl font-bold mb-6 flex items-center">
          <Award className="w-6 h-6 mr-2" /> Your Certificates
        </h2>
        
        {user.coursesCompleted > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {Array.from({ length: Math.min(4, user.coursesCompleted) }).map((_, idx) => {
              const certCourse = myCourses.completed[idx % myCourses.completed.length];
              return (
                <div
                  key={idx}
                  className={`p-6 rounded-xl border-2 ${
                    theme === 'dark'
                      ? 'bg-gray-800 border-gray-700'
                      : 'bg-white border-blue-100'
                  } flex flex-col items-center text-center relative overflow-hidden`}
                >
                  <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-blue-500/10"></div>
                  <div className="absolute top-0 right-0 left-0 h-1 bg-gradient-to-r from-blue-500 to-purple-500"></div>
                  
                  <Award className={`w-12 h-12 mb-3 ${
                    theme === 'dark' ? 'text-yellow-300' : 'text-yellow-500'
                  }`} />
                  
                  <h3 className="font-semibold mb-1">{certCourse.title}</h3>
                  <p className="text-sm opacity-75 mb-4">Completed on June 15, 2025</p>
                  
                  <Link
                    to="#"
                    className={`text-sm ${
                      theme === 'dark' ? 'text-blue-300' : 'text-blue-600'
                    } hover:underline mt-auto`}
                  >
                    View Certificate
                  </Link>
                </div>
              );
            })}
          </div>
        ) : (
          <div className={`text-center py-12 px-4 rounded-xl ${
            theme === 'dark' ? 'bg-gray-800' : 'bg-gray-100'
          }`}>
            <p className="mb-2">Complete courses to earn certificates</p>
            <Link
              to="/courses"
              className={`px-4 py-2 rounded-lg mt-4 inline-block ${
                theme === 'dark'
                  ? 'bg-blue-600 hover:bg-blue-700'
                  : 'bg-blue-600 hover:bg-blue-700'
              } text-white transition-colors`}
            >
              Browse courses
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;